/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *openFile;
    QLabel *dirName;
    QPushButton *updateButton;
    QHBoxLayout *horizontalLayout_2;
    QPlainTextEdit *searchField;
    QPushButton *clear;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_5;
    QTreeView *treeView;
    QGroupBox *verticalGroupBox;
    QVBoxLayout *verticalLayout_3;
    QPushButton *delete_2;
    QPushButton *rename;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QLabel *indexLabel;
    QProgressBar *indexBar;
    QHBoxLayout *horizontalLayout_4;
    QLabel *searchLabel;
    QProgressBar *searchBar;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setWindowModality(Qt::WindowModality::ApplicationModal);
        MainWindow->resize(509, 409);
        MainWindow->setMinimumSize(QSize(509, 409));
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(15, 15, 15, 15);
        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setMinimumSize(QSize(451, 311));
        frame->setStyleSheet(QString::fromUtf8(""));
        frame->setFrameShape(QFrame::Shape::Box);
        frame->setFrameShadow(QFrame::Shadow::Sunken);
        frame->setLineWidth(1);
        frame->setMidLineWidth(1);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(12, 12, 12, 12);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        openFile = new QPushButton(frame);
        openFile->setObjectName("openFile");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(openFile->sizePolicy().hasHeightForWidth());
        openFile->setSizePolicy(sizePolicy1);
        openFile->setMinimumSize(QSize(60, 20));
        openFile->setMaximumSize(QSize(60, 20));
        QIcon icon(QIcon::fromTheme(QString::fromUtf8("folder-open")));
        openFile->setIcon(icon);
        openFile->setIconSize(QSize(30, 20));
        openFile->setCheckable(true);
        openFile->setFlat(true);

        horizontalLayout->addWidget(openFile);

        dirName = new QLabel(frame);
        dirName->setObjectName("dirName");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(dirName->sizePolicy().hasHeightForWidth());
        dirName->setSizePolicy(sizePolicy2);
        dirName->setMinimumSize(QSize(0, 20));
        dirName->setMaximumSize(QSize(16777215, 20));
        dirName->setStyleSheet(QString::fromUtf8("border-color: rgb(161, 161, 161);"));
        dirName->setFrameShape(QFrame::Shape::WinPanel);
        dirName->setFrameShadow(QFrame::Shadow::Sunken);
        dirName->setLineWidth(0);

        horizontalLayout->addWidget(dirName);

        updateButton = new QPushButton(frame);
        updateButton->setObjectName("updateButton");
        updateButton->setMinimumSize(QSize(20, 20));
        updateButton->setMaximumSize(QSize(20, 20));
        updateButton->setMouseTracking(true);
        updateButton->setTabletTracking(true);
        QIcon icon1(QIcon::fromTheme(QString::fromUtf8("emblem-synchronized")));
        updateButton->setIcon(icon1);

        horizontalLayout->addWidget(updateButton);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        searchField = new QPlainTextEdit(frame);
        searchField->setObjectName("searchField");
        searchField->setMinimumSize(QSize(0, 20));
        searchField->setMaximumSize(QSize(16777215, 20));
        searchField->setCenterOnScroll(true);

        horizontalLayout_2->addWidget(searchField);

        clear = new QPushButton(frame);
        clear->setObjectName("clear");
        sizePolicy1.setHeightForWidth(clear->sizePolicy().hasHeightForWidth());
        clear->setSizePolicy(sizePolicy1);
        clear->setMinimumSize(QSize(0, 20));
        clear->setMaximumSize(QSize(16777215, 20));
        QIcon icon2(QIcon::fromTheme(QIcon::ThemeIcon::EditClear));
        clear->setIcon(icon2);
        clear->setIconSize(QSize(10, 10));

        horizontalLayout_2->addWidget(clear);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_2 = new QSpacerItem(20, 10, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        treeView = new QTreeView(frame);
        treeView->setObjectName("treeView");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::MinimumExpanding, QSizePolicy::Policy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(treeView->sizePolicy().hasHeightForWidth());
        treeView->setSizePolicy(sizePolicy3);
        treeView->setAlternatingRowColors(true);
        treeView->setSelectionMode(QAbstractItemView::SelectionMode::ContiguousSelection);
        treeView->setSelectionBehavior(QAbstractItemView::SelectionBehavior::SelectRows);
        treeView->setTextElideMode(Qt::TextElideMode::ElideRight);

        horizontalLayout_5->addWidget(treeView);

        verticalGroupBox = new QGroupBox(frame);
        verticalGroupBox->setObjectName("verticalGroupBox");
        QSizePolicy sizePolicy4(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(verticalGroupBox->sizePolicy().hasHeightForWidth());
        verticalGroupBox->setSizePolicy(sizePolicy4);
        verticalGroupBox->setMinimumSize(QSize(0, 50));
        verticalGroupBox->setMaximumSize(QSize(16777215, 80));
        verticalLayout_3 = new QVBoxLayout(verticalGroupBox);
        verticalLayout_3->setObjectName("verticalLayout_3");
        delete_2 = new QPushButton(verticalGroupBox);
        delete_2->setObjectName("delete_2");
        sizePolicy1.setHeightForWidth(delete_2->sizePolicy().hasHeightForWidth());
        delete_2->setSizePolicy(sizePolicy1);
        delete_2->setMinimumSize(QSize(0, 20));
        delete_2->setMaximumSize(QSize(16777215, 20));

        verticalLayout_3->addWidget(delete_2);

        rename = new QPushButton(verticalGroupBox);
        rename->setObjectName("rename");
        sizePolicy1.setHeightForWidth(rename->sizePolicy().hasHeightForWidth());
        rename->setSizePolicy(sizePolicy1);
        rename->setMinimumSize(QSize(0, 20));
        rename->setMaximumSize(QSize(16777215, 20));

        verticalLayout_3->addWidget(rename);


        horizontalLayout_5->addWidget(verticalGroupBox);


        verticalLayout->addLayout(horizontalLayout_5);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        verticalLayout->addItem(verticalSpacer);


        verticalLayout_2->addWidget(frame);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        indexLabel = new QLabel(centralwidget);
        indexLabel->setObjectName("indexLabel");
        indexLabel->setMinimumSize(QSize(60, 20));
        indexLabel->setMaximumSize(QSize(60, 20));

        horizontalLayout_3->addWidget(indexLabel);

        indexBar = new QProgressBar(centralwidget);
        indexBar->setObjectName("indexBar");
        indexBar->setMinimumSize(QSize(0, 20));
        indexBar->setMaximumSize(QSize(16777215, 20));
        indexBar->setValue(0);

        horizontalLayout_3->addWidget(indexBar);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        searchLabel = new QLabel(centralwidget);
        searchLabel->setObjectName("searchLabel");
        searchLabel->setMinimumSize(QSize(60, 20));
        searchLabel->setMaximumSize(QSize(60, 20));

        horizontalLayout_4->addWidget(searchLabel);

        searchBar = new QProgressBar(centralwidget);
        searchBar->setObjectName("searchBar");
        searchBar->setMinimumSize(QSize(0, 20));
        searchBar->setMaximumSize(QSize(16777215, 20));
        searchBar->setValue(0);

        horizontalLayout_4->addWidget(searchBar);


        verticalLayout_2->addLayout(horizontalLayout_4);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 509, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "String search", nullptr));
#if QT_CONFIG(tooltip)
        openFile->setToolTip(QCoreApplication::translate("MainWindow", "Open folder", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        dirName->setToolTip(QCoreApplication::translate("MainWindow", "Directory path", nullptr));
#endif // QT_CONFIG(tooltip)
        dirName->setText(QString());
#if QT_CONFIG(tooltip)
        updateButton->setToolTip(QCoreApplication::translate("MainWindow", "Update data", " "));
#endif // QT_CONFIG(tooltip)
        updateButton->setText(QString());
#if QT_CONFIG(tooltip)
        searchField->setToolTip(QCoreApplication::translate("MainWindow", "Searching string", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        clear->setToolTip(QCoreApplication::translate("MainWindow", "Clear ", nullptr));
#endif // QT_CONFIG(tooltip)
        clear->setText(QString());
        delete_2->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
        rename->setText(QCoreApplication::translate("MainWindow", "Rename", nullptr));
        indexLabel->setText(QCoreApplication::translate("MainWindow", "Indexing", nullptr));
        searchLabel->setText(QCoreApplication::translate("MainWindow", "Searching", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
